# Crossgrounds — Icon Atlas v1.0

Atlas de 48 ícones dos menus do Crossgrounds, com ilustrações vetoriais originais de traço uniforme (24×24, stroke 1.8, terminais arredondados). PNGs brancos com fundo transparente, recoloríveis usando `ImageColor3` no Roblox.

## Arquivos
- `crossgrounds-menu-icons-atlas.png` — atlas PNG transparente 768×576, 8 colunas × 6 linhas, cada célula 96×96.
- `crossgrounds-menu-icons-preview.png` — prancha de referência com nomes (não usar como atlas no jogo).
- `crossgrounds-menu-icons-atlas.json` — identificador, rótulo e coordenadas exatas de cada célula.
- `IconAtlasMap.luau` — tabela com retângulos `ImageRectOffset`/`ImageRectSize`.
- `icons/*.svg`, `icons/*.png` — versões vetoriais e raster individuais.

## Roblox
Carregue o atlas PNG no Roblox como imagem, atribua o mesmo `rbxassetid://...` aos ImageLabels e defina `ImageRectOffset` e `ImageRectSize` pelo mapa. Use `ScaleType = Fit` para preservar proporções; tintura e brilho de seleção são feitos pela interface, **não gravados nas imagens**. Não use a prévia rotulada no jogo.

## Proveniência das opções
Inventário derivado da branch `master` do repositório [Kauziin/Crossgrounds](https://github.com/Kauziin/Crossgrounds), especialmente `ExperienceMenu.luau` (Categorias/Controles/Mira), `HubController.luau` (tela inicial), `ProgressionView.luau` (Progresso), `JoinMenu.luau` (kits/CTF) e `LobbyMusicMenu.luau` (playlist). Alguns identificadores são **ícones utilitários adicionais** — como confirmar, voltar, personalizar, restaurar e silenciar — e não entradas independentes de menu.

Nenhum código do repositório foi modificado.

## Atlas de opções individuais (extra)
- `crossgrounds-settings-icons-atlas.png` — segundo atlas PNG transparente 768×480 (8×5, 40 células 96×96).
- `crossgrounds-settings-icons-preview.png` — prévia com os nomes de cada opção.
- `crossgrounds-settings-icons-atlas.json` e `SettingsIconAtlasMap.luau` — metadados, usando **exatamente** os IDs das 40 preferências em `src/ReplicatedStorage/ExperienceSettings.luau`.
- `settings-icons/*.svg` e `settings-icons/*.png` — arquivos individuais das 40 preferências.

Os controles de HUD móvel (posição/tamanho/opacidade por botão) são configurações geradas dinamicamente; eles reutilizam ícones sem criar um atlas para cada coordenada.
